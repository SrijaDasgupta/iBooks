import React from "react";

class RegisterForm extends React.Component {
  state = {
    data: {
      email: "",
      password: "",
      passwordRepeat: "",
    },
    errors: {},
    passwordError: "",
  };

  validateProperty = (input) => {};

  handleChange = () => {};

  validate = () => {};

  handleSubmit = (e) => {};

  schema = {};

  render() {}
}
